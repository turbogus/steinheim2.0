Lava Lamps (lavalamp) mod for Minetest


by thefamilygrog66

Description:
Coloured Lava Lamps, loosely based on Tonyka's wall torches from the 3dforniture/homedecor mod. There are 6 colours in all: red, orange, yellow, green, blue, violet.

After placing a lava lamp, the player can turn it off/on again by right-clicking on it.

Recipe:

+---------------+
| coloured wool |
+---------------+
| water bucket  |
+---------------+
|  black wool   |
+---------------+

Mod dependencies: wool, bucket

License:
Sourcecode: WTFPL (see below)
Graphics: WTFPL (see below)

See also:
http://minetest.net/

         DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
                    Version 2, December 2004

 Copyright (C) 2004 Sam Hocevar <sam@hocevar.net>

 Everyone is permitted to copy and distribute verbatim or modified
 copies of this license document, and changing it is allowed as long
 as the name is changed.

            DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
   TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION

  0. You just DO WHAT THE FUCK YOU WANT TO.
