# Coloured Stone Bricks
This mod adds coloured stone bricks! These are decorative blocks which would look nice on any building or creation.

**Depends:** default, dye
**License:** Code and textures, CC BY-SA 4.0
**Installation:** Unzip the file and rename it to "colouredstonebricks". Then move it to the mod directory.

- Forum Topic: https://forum.minetest.net/viewtopic.php?id=8784
