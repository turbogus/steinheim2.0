--Les cheminées de homedecor (conflit avec les slabs de moreblocs)
minetest.register_craft({
	output = 'fake_fire:chimney_top_stone',
	recipe = {
		{'default:stone','default:torch','default:stone'},
	}
})
minetest.register_craft({
	output = 'fake_fire:chimney_top_sandstone',
	recipe = {
		{'default:sandstone','default:torch','default:sandstone'},
	}
})

-- Raccourcie pour le sand et inverse
minetest.register_craft({
	output = 'default:gravel 3',
	recipe = {
		{'default:cobble'},
	}
})
minetest.register_craft({
	output = 'default:sand 3',
	recipe = {
		{'default:gravel'},
	}
})
minetest.register_craft({
	output = 'default:gravel',
	recipe = {
		{'group:sand'},
		{'group:sand'},
		{'group:sand'},
	}
})
minetest.register_craft({
	output = 'default:cobble',
	recipe = {
		{'default:gravel'},
		{'default:gravel'},
		{'default:gravel'},
	}
})

-- Raccourcie pour les clay_lump
minetest.register_craft({
	output = 'default:clay_lump 4',
	recipe = {
		{'group:sand'},
		{'default:dirt'},
		{'bucket:bucket_water'},
	},
	replacements = {{"bucket:bucket_water", "bucket:bucket_empty"}},
})

-- Création de clay quand on pose un bloc de gravel dans l'eau
default.gen_clay = function(pos)	
	minetest.set_node(pos, {name="default:clay"})
end
minetest.register_abm({
	nodenames = {"default:gravel"},
	neighbors = {"default:water_source"},
	interval = 3,
	chance = 1,
	action = function(pos, node, active_object_count, active_object_count_wider)
		default.gen_clay(pos, node, active_object_count, active_object_count_wider)
	end,
})
