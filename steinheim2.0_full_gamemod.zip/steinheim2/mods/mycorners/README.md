*****************************************************************
*								*
*	      This mod was made by the MaxBat Team		*
*								*
*	     Team includes - MaxCohen And Don Batman		*
*								*
*	        This mod is licenced under WTFPL		*
*								*
*****************************************************************

mycorners
========
Code for machine based off of Noncubic by yves_de_beck

mycorners adds corners to many default blocks.

To use simply craft a corner machine. Then put in wood, stone or stone brick. Click Make. This gives you your corner items.
Then craft a corner installer machine. Put in the block you want a corner on and the corner items you want installed. Click Make.

Craft
-------
Corner Machine
--------------
  	x		default:steel_ingiot		default:wood
default:steelblock	default:steelblock			x
default:steelblock	default:steelblock			x


