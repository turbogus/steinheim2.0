mycorners = {}
dofile(minetest.get_modpath("mycorners").."/cornertool.lua")
dofile(minetest.get_modpath("mycorners").."/nodes.lua")
dofile(minetest.get_modpath("mycorners").."/machine.lua")
dofile(minetest.get_modpath("mycorners").."/register.lua")
--dofile(minetest.get_modpath("mycorners").."/corners.lua")








